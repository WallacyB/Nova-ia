# ✦ NOVA AI — Deploy no Netlify

## Estrutura
```
nova-ai/
├── netlify/
│   └── functions/
│       ├── chat.js        → /api/chat
│       └── providers.js   → /api/providers
├── src/
│   ├── main.jsx
│   └── App.jsx
├── index.html
├── package.json
├── vite.config.js
└── netlify.toml
```

---

## 🚀 Deploy passo a passo (pelo celular/browser)

### PASSO 1 — Subir no GitHub

1. Acessa **github.com** → login
2. Clica em **"New repository"** (botão verde +)
3. Nome: `nova-ai`
4. Deixa **Public**
5. Clica **"Create repository"**
6. Na página do repo vazio, clica **"uploading an existing file"**
7. Arrasta todos os arquivos desta pasta (mantendo a estrutura de pastas)
8. Clica **"Commit changes"**

### PASSO 2 — Deploy no Netlify

1. Acessa **netlify.com** → login com GitHub
2. Clica **"Add new site"** → **"Import an existing project"**
3. Escolhe **GitHub** → seleciona o repo `nova-ai`
4. Configurações de build:
   - Build command: `npm run build`
   - Publish directory: `dist`
5. Clica **"Deploy site"**

### PASSO 3 — Adicionar as chaves da API

1. No Netlify, vai em **Site → Environment Variables**
2. Adiciona as chaves que tens:

| Variable | Onde obter |
|---|---|
| `ANTHROPIC_API_KEY` | console.anthropic.com/keys |
| `OPENAI_API_KEY` | platform.openai.com/api-keys |
| `GEMINI_API_KEY` | aistudio.google.com/app/apikey |
| `GROQ_API_KEY` | console.groq.com/keys ← **GRÁTIS** |
| `MISTRAL_API_KEY` | console.mistral.ai/api-keys |

3. Depois de adicionar, vai em **Deploys → Trigger deploy → Deploy site**
4. Aguarda ~1 minuto e acessa a URL gerada pelo Netlify

---

## ✅ Resultado

- URL pública tipo: `https://nova-ai-xyz.netlify.app`
- Funciona no celular, PC, qualquer lugar
- Backend rodando dentro do Netlify (sem servidor separado)
- Chaves seguras no servidor (nunca expostas no frontend)

---

## 🔑 Chaves grátis para começar

**Groq** é 100% grátis: https://console.groq.com
Dá acesso a Llama 3.3 70B, Mixtral, Gemma — modelos poderosos sem custo.
