import { useState, useRef, useEffect } from "react";

// ─── Modos de personalidade ───────────────────────────────────────────────────
const MODES = [
  { id: "genius",   label: "🧠 Gênio",       system: "Você é NOVA, uma IA criativa e analítica. Responda em português do Brasil com insights profundos e memoráveis." },
  { id: "code",     label: "💻 Dev Elite",    system: "Você é NOVA, engenheiro sênior full-stack. Código limpo, TypeScript/React/Node. Responda em português do Brasil." },
  { id: "copy",     label: "✍️ Copywriter",   system: "Você é NOVA, expert em copy de alta conversão BR/ES. Headlines magnéticas, CTAs irresistíveis. Responda em português do Brasil." },
  { id: "strategy", label: "📈 Estrategista", system: "Você é NOVA, estrategista de negócios digitais. Planos acionáveis e estruturados. Responda em português do Brasil." },
  { id: "creative", label: "🎨 Criativo",     system: "Você é NOVA, diretor criativo visionário. Ideias únicas e memoráveis. Responda em português do Brasil." },
];

const SUGGESTIONS = [
  "Como criar um produto digital que vende sozinho?",
  "Escreva um hook magnético para Instagram sobre IA",
  "Analise uma estratégia de Meta Ads para infoprodutos",
  "Estrutura de landing page de alta conversão",
  "Como escalar um negócio digital rapidamente?",
];

// Cores por provider
const PROVIDER_COLORS = {
  anthropic: { bg: "#c2410c", light: "#fed7aa", dot: "#f97316" },
  openai:    { bg: "#15803d", light: "#bbf7d0", dot: "#22c55e" },
  gemini:    { bg: "#1d4ed8", light: "#bfdbfe", dot: "#3b82f6" },
  groq:      { bg: "#7e22ce", light: "#e9d5ff", dot: "#a855f7" },
  mistral:   { bg: "#be123c", light: "#fecdd3", dot: "#f43f5e" },
};

async function askNova(messages, system, provider, model) {
  const res = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messages, system, provider, model }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data.reply;
}

// ─── Componentes ──────────────────────────────────────────────────────────────
function Dots({ color }) {
  return (
    <div style={{ display: "flex", gap: 5, padding: "13px 15px" }}>
      {[0, 1, 2].map((i) => (
        <span key={i} style={{
          width: 7, height: 7, borderRadius: "50%", display: "inline-block",
          background: color || "linear-gradient(135deg,#a78bfa,#60a5fa)",
          animation: `blink 1.2s ${i * 0.2}s ease-in-out infinite`,
        }} />
      ))}
    </div>
  );
}

function Bubble({ msg, providerColor }) {
  const u = msg.role === "user";
  return (
    <div style={{ display: "flex", justifyContent: u ? "flex-end" : "flex-start", marginBottom: 14, animation: "popIn .25s ease-out" }}>
      {!u && (
        <div style={{
          width: 30, height: 30, borderRadius: "50%", flexShrink: 0, marginRight: 8, marginTop: 2,
          background: `linear-gradient(135deg, ${providerColor?.dot || "#7c3aed"}, #2563eb)`,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 13, boxShadow: `0 0 10px ${providerColor?.dot || "#7c3aed"}55`,
        }}>✦</div>
      )}
      <div style={{
        maxWidth: "78%", padding: "11px 15px",
        borderRadius: u ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
        background: u ? "linear-gradient(135deg,#7c3aed,#4f46e5)" : "rgba(255,255,255,.06)",
        border: u ? "none" : "1px solid rgba(255,255,255,.09)",
        color: "#f1f5f9", fontSize: 14, lineHeight: 1.7, whiteSpace: "pre-wrap", wordBreak: "break-word",
      }}>
        {msg.content}
      </div>
    </div>
  );
}

function ModelSelector({ providers, selectedProvider, selectedModel, onChange }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const currentProvider = providers.find(p => p.id === selectedProvider);
  const currentModel = currentProvider?.models.find(m => m.id === selectedModel);
  const color = PROVIDER_COLORS[selectedProvider] || PROVIDER_COLORS.anthropic;

  if (!providers.length) return (
    <div style={{ fontSize: 11, color: "#64748b", padding: "4px 10px" }}>Carregando modelos...</div>
  );

  return (
    <div ref={ref} style={{ position: "relative" }}>
      <button onClick={() => setOpen(!open)} style={{
        display: "flex", alignItems: "center", gap: 8, padding: "6px 12px",
        background: "rgba(255,255,255,.05)", border: "1px solid rgba(255,255,255,.12)",
        borderRadius: 10, cursor: "pointer", color: "#f1f5f9", fontSize: 12,
      }}>
        <span style={{ width: 8, height: 8, borderRadius: "50%", background: color.dot, flexShrink: 0 }} />
        <span style={{ color: "#94a3b8", fontSize: 10 }}>{currentProvider?.name}</span>
        <span style={{ color: "#f1f5f9", fontWeight: 600 }}>{currentModel?.label || selectedModel}</span>
        <span style={{ color: "#475569", fontSize: 10 }}>{open ? "▲" : "▼"}</span>
      </button>

      {open && (
        <div style={{
          position: "absolute", top: "calc(100% + 6px)", left: 0,
          background: "#0f0f1a", border: "1px solid rgba(255,255,255,.1)",
          borderRadius: 12, padding: 8, zIndex: 100, minWidth: 220,
          boxShadow: "0 8px 32px rgba(0,0,0,.6)",
        }}>
          {providers.map((p) => {
            const pc = PROVIDER_COLORS[p.id] || PROVIDER_COLORS.anthropic;
            return (
              <div key={p.id}>
                <div style={{ padding: "6px 8px 4px", fontSize: 10, color: "#475569", fontWeight: 700, letterSpacing: ".8px", display: "flex", alignItems: "center", gap: 6 }}>
                  <span style={{ width: 6, height: 6, borderRadius: "50%", background: p.configured ? pc.dot : "#374151" }} />
                  {p.name.toUpperCase()}
                  {!p.configured && <span style={{ color: "#ef4444", fontSize: 9 }}>• SEM CHAVE</span>}
                </div>
                {p.models.map((m) => (
                  <button key={m.id}
                    disabled={!p.configured}
                    onClick={() => { onChange(p.id, m.id); setOpen(false); }}
                    style={{
                      display: "block", width: "100%", textAlign: "left",
                      padding: "7px 8px 7px 20px", borderRadius: 8, border: "none",
                      background: selectedProvider === p.id && selectedModel === m.id
                        ? `rgba(${p.id === "anthropic" ? "249,115,22" : p.id === "openai" ? "34,197,94" : p.id === "gemini" ? "59,130,246" : p.id === "groq" ? "168,85,247" : "244,63,94"},.15)`
                        : "transparent",
                      color: !p.configured ? "#374151" : selectedProvider === p.id && selectedModel === m.id ? pc.light : "#94a3b8",
                      fontSize: 12.5, cursor: p.configured ? "pointer" : "not-allowed",
                      marginBottom: 1,
                    }}
                    onMouseEnter={e => { if (p.configured) e.currentTarget.style.background = "rgba(255,255,255,.06)"; }}
                    onMouseLeave={e => {
                      if (p.configured) e.currentTarget.style.background = selectedProvider === p.id && selectedModel === m.id
                        ? `rgba(255,255,255,.1)` : "transparent";
                    }}
                  >{m.label}</button>
                ))}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── App principal ────────────────────────────────────────────────────────────
export default function NovaAI() {
  const [msgs, setMsgs] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState(MODES[0]);
  const [showTips, setShowTips] = useState(true);
  const [err, setErr] = useState("");
  const [providers, setProviders] = useState([]);
  const [selectedProvider, setSelectedProvider] = useState("anthropic");
  const [selectedModel, setSelectedModel] = useState("claude-sonnet-4-6");
  const bottomRef = useRef(null);
  const taRef = useRef(null);

  // Carrega providers disponíveis do backend
  useEffect(() => {
    fetch("/api/providers")
      .then(r => r.json())
      .then(data => {
        setProviders(data);
        // Seleciona o primeiro provider com chave configurada
        const first = data.find(p => p.configured);
        if (first) { setSelectedProvider(first.id); setSelectedModel(first.models[0].id); }
      })
      .catch(() => {}); // backend pode estar offline
  }, []);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, loading]);

  const handleProviderChange = (provider, model) => {
    setSelectedProvider(provider);
    setSelectedModel(model);
  };

  const send = async (text) => {
    const txt = (text ?? input).trim();
    if (!txt || loading) return;
    setInput(""); setErr(""); setShowTips(false);
    if (taRef.current) taRef.current.style.height = "auto";
    const next = [...msgs, { role: "user", content: txt }];
    setMsgs(next);
    setLoading(true);
    try {
      const reply = await askNova(next, mode.system, selectedProvider, selectedModel);
      setMsgs([...next, { role: "assistant", content: reply }]);
    } catch (e) {
      setErr(e.message);
      setMsgs(msgs);
    } finally {
      setLoading(false);
      setTimeout(() => taRef.current?.focus(), 50);
    }
  };

  const onKey = (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } };
  const reset = () => { setMsgs([]); setShowTips(true); setInput(""); setErr(""); };

  const color = PROVIDER_COLORS[selectedProvider] || PROVIDER_COLORS.anthropic;

  return (
    <div style={{
      minHeight: "100vh",
      background: "radial-gradient(ellipse at 20% 0%,#1e0a3c 0%,#0b0b18 45%,#000308 100%)",
      fontFamily: "'Inter',system-ui,sans-serif", color: "#f1f5f9", display: "flex", flexDirection: "column",
    }}>
      <style>{`
        @keyframes blink{0%,100%{opacity:.25;transform:scale(.9)}50%{opacity:1;transform:scale(1.2)}}
        @keyframes popIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
        @keyframes glow{0%,100%{box-shadow:0 0 18px rgba(124,58,237,.35)}50%{box-shadow:0 0 36px rgba(124,58,237,.7)}}
        *{box-sizing:border-box;}
        textarea{resize:none;outline:none;font-family:inherit;}
        button{font-family:inherit;cursor:pointer;transition:all .18s;}
        ::-webkit-scrollbar{width:3px;}
        ::-webkit-scrollbar-thumb{background:rgba(124,58,237,.5);border-radius:3px;}
      `}</style>

      {/* ── Header ── */}
      <div style={{ padding: "14px 18px 10px", borderBottom: "1px solid rgba(255,255,255,.06)", background: "rgba(0,0,0,.5)", backdropFilter: "blur(18px)", position: "sticky", top: 0, zIndex: 50 }}>
        {/* Linha 1: logo + model selector + reset */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: `linear-gradient(135deg, ${color.dot}, #2563eb)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, animation: "glow 3s ease-in-out infinite", transition: "background .4s" }}>✦</div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 15 }}>NOVA <span style={{ background: "linear-gradient(135deg,#a78bfa,#60a5fa)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>AI</span></div>
              <div style={{ fontSize: 9, color: "#475569", letterSpacing: ".5px" }}>{mode.label.toUpperCase()}</div>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <ModelSelector providers={providers} selectedProvider={selectedProvider} selectedModel={selectedModel} onChange={handleProviderChange} />
            {msgs.length > 0 && (
              <button onClick={reset} style={{ background: "rgba(255,255,255,.05)", border: "1px solid rgba(255,255,255,.1)", color: "#64748b", padding: "5px 10px", borderRadius: 8, fontSize: 11 }}>↺</button>
            )}
          </div>
        </div>

        {/* Linha 2: mode pills */}
        <div style={{ display: "flex", gap: 6, overflowX: "auto", paddingBottom: 2 }}>
          {MODES.map((m) => (
            <button key={m.id} onClick={() => setMode(m)} style={{
              padding: "4px 10px", borderRadius: 20, fontSize: 11, fontWeight: 500, whiteSpace: "nowrap",
              border: mode.id === m.id ? `1px solid ${color.dot}88` : "1px solid rgba(255,255,255,.07)",
              background: mode.id === m.id ? `${color.dot}22` : "rgba(255,255,255,.03)",
              color: mode.id === m.id ? color.light : "#64748b",
            }}>{m.label}</button>
          ))}
        </div>
      </div>

      {/* ── Messages ── */}
      <div style={{ flex: 1, overflowY: "auto", padding: "20px 18px" }}>
        {msgs.length === 0 && showTips && (
          <div style={{ textAlign: "center", paddingTop: 16 }}>
            <div style={{ fontSize: 40, marginBottom: 10, display: "inline-block", animation: "glow 3s ease-in-out infinite" }}>✦</div>
            <div style={{ fontSize: 20, fontWeight: 700, marginBottom: 6 }}>
              Olá, sou a <span style={{ background: "linear-gradient(135deg,#a78bfa,#60a5fa)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>NOVA</span>
            </div>
            <div style={{ color: "#64748b", fontSize: 13, marginBottom: 24 }}>Escolhe o modelo e o modo — e vamos começar.</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 7, maxWidth: 440, margin: "0 auto" }}>
              {SUGGESTIONS.map((s, i) => (
                <button key={i} onClick={() => send(s)} style={{
                  background: "rgba(255,255,255,.03)", border: "1px solid rgba(255,255,255,.08)",
                  borderRadius: 12, padding: "10px 15px", color: "#94a3b8", fontSize: 13, textAlign: "left",
                }}
                  onMouseEnter={e => { e.currentTarget.style.background = `${color.dot}18`; e.currentTarget.style.color = color.light; e.currentTarget.style.borderColor = `${color.dot}44`; }}
                  onMouseLeave={e => { e.currentTarget.style.background = "rgba(255,255,255,.03)"; e.currentTarget.style.color = "#94a3b8"; e.currentTarget.style.borderColor = "rgba(255,255,255,.08)"; }}>
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {msgs.map((m, i) => <Bubble key={i} msg={m} providerColor={color} />)}

        {loading && (
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
            <div style={{ width: 30, height: 30, borderRadius: "50%", background: `linear-gradient(135deg, ${color.dot}, #2563eb)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, boxShadow: `0 0 10px ${color.dot}55` }}>✦</div>
            <div style={{ background: "rgba(255,255,255,.06)", border: "1px solid rgba(255,255,255,.09)", borderRadius: "18px 18px 18px 4px" }}>
              <Dots color={color.dot} />
            </div>
          </div>
        )}

        {err && (
          <div style={{ background: "rgba(239,68,68,.09)", border: "1px solid rgba(239,68,68,.25)", borderRadius: 10, padding: "12px 14px", marginBottom: 14 }}>
            <div style={{ color: "#f87171", fontSize: 13, fontWeight: 600, marginBottom: 4 }}>❌ Erro</div>
            <div style={{ color: "#94a3b8", fontSize: 11, fontFamily: "monospace", lineHeight: 1.6, wordBreak: "break-all" }}>{err}</div>
            <button onClick={() => setErr("")} style={{ marginTop: 8, background: "rgba(255,255,255,.05)", border: "1px solid rgba(255,255,255,.1)", color: "#94a3b8", padding: "3px 9px", borderRadius: 6, fontSize: 11 }}>Fechar</button>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* ── Input ── */}
      <div style={{ padding: "12px 18px 18px", background: "rgba(0,0,0,.55)", backdropFilter: "blur(18px)", borderTop: "1px solid rgba(255,255,255,.06)" }}>
        <div style={{ display: "flex", gap: 9, alignItems: "flex-end", background: "rgba(255,255,255,.05)", border: `1px solid ${color.dot}33`, borderRadius: 13, padding: "9px 11px", transition: "border-color .3s" }}>
          <textarea ref={taRef} value={input} onChange={e => setInput(e.target.value)} onKeyDown={onKey}
            placeholder={`Fale com a NOVA (${mode.label.replace(/^[^\s]+\s/, "")})...`} rows={1}
            style={{ flex: 1, background: "transparent", border: "none", color: "#f1f5f9", fontSize: 14, lineHeight: 1.5, maxHeight: 110, overflowY: "auto" }}
            onInput={e => { e.target.style.height = "auto"; e.target.style.height = Math.min(e.target.scrollHeight, 110) + "px"; }} />
          <button onClick={() => send()} disabled={!input.trim() || loading} style={{
            width: 33, height: 33, borderRadius: 8, flexShrink: 0, border: "none",
            background: input.trim() && !loading ? `linear-gradient(135deg, ${color.dot}, #4f46e5)` : "rgba(255,255,255,.05)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 15, color: "#fff", opacity: input.trim() && !loading ? 1 : 0.35, transition: "all .2s",
          }}>↑</button>
        </div>
        <div style={{ textAlign: "center", fontSize: "10px", color: "#1e293b", marginTop: 6 }}>
          Enter para enviar · Shift+Enter para nova linha
        </div>
      </div>
    </div>
  );
}
