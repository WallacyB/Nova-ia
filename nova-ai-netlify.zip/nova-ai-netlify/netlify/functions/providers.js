// Netlify Function: /api/providers
// Retorna quais providers têm chave configurada

const PROVIDERS_META = [
  {
    id: "anthropic",
    name: "Anthropic",
    envKey: "ANTHROPIC_API_KEY",
    models: [
      { id: "claude-sonnet-4-6",         label: "Claude Sonnet 4.6" },
      { id: "claude-opus-4-5",           label: "Claude Opus 4.5" },
      { id: "claude-haiku-4-5-20251001", label: "Claude Haiku 4.5" },
    ],
  },
  {
    id: "openai",
    name: "OpenAI",
    envKey: "OPENAI_API_KEY",
    models: [
      { id: "gpt-4o",      label: "GPT-4o" },
      { id: "gpt-4o-mini", label: "GPT-4o Mini" },
      { id: "o3-mini",     label: "o3 Mini" },
    ],
  },
  {
    id: "gemini",
    name: "Google Gemini",
    envKey: "GEMINI_API_KEY",
    models: [
      { id: "gemini-2.0-flash",            label: "Gemini 2.0 Flash" },
      { id: "gemini-2.5-pro-preview-06-05", label: "Gemini 2.5 Pro" },
    ],
  },
  {
    id: "groq",
    name: "Groq (Grátis)",
    envKey: "GROQ_API_KEY",
    models: [
      { id: "llama-3.3-70b-versatile", label: "Llama 3.3 70B" },
      { id: "llama-3.1-8b-instant",    label: "Llama 3.1 8B" },
      { id: "mixtral-8x7b-32768",      label: "Mixtral 8x7B" },
      { id: "gemma2-9b-it",            label: "Gemma 2 9B" },
    ],
  },
  {
    id: "mistral",
    name: "Mistral",
    envKey: "MISTRAL_API_KEY",
    models: [
      { id: "mistral-large-latest", label: "Mistral Large" },
      { id: "mistral-small-latest", label: "Mistral Small" },
      { id: "codestral-latest",     label: "Codestral" },
    ],
  },
];

export const handler = async () => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Content-Type": "application/json",
  };

  const result = PROVIDERS_META.map((p) => ({
    ...p,
    configured: !!process.env[p.envKey],
  }));

  return { statusCode: 200, headers, body: JSON.stringify(result) };
};
