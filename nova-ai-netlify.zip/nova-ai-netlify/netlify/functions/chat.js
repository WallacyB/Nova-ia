// Netlify Function: /api/chat
// Suporta: Anthropic, OpenAI, Gemini, Groq, Mistral

const PROVIDERS = {
  anthropic: {
    baseURL: "https://api.anthropic.com/v1/messages",
    envKey: "ANTHROPIC_API_KEY",
    models: ["claude-sonnet-4-6", "claude-opus-4-5", "claude-haiku-4-5-20251001"],
  },
  openai: {
    baseURL: "https://api.openai.com/v1/chat/completions",
    envKey: "OPENAI_API_KEY",
    models: ["gpt-4o", "gpt-4o-mini", "o3-mini"],
  },
  gemini: {
    baseURL: "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
    envKey: "GEMINI_API_KEY",
    models: ["gemini-2.0-flash", "gemini-2.5-pro-preview-06-05"],
  },
  groq: {
    baseURL: "https://api.groq.com/openai/v1/chat/completions",
    envKey: "GROQ_API_KEY",
    models: ["llama-3.3-70b-versatile", "llama-3.1-8b-instant", "mixtral-8x7b-32768", "gemma2-9b-it"],
  },
  mistral: {
    baseURL: "https://api.mistral.ai/v1/chat/completions",
    envKey: "MISTRAL_API_KEY",
    models: ["mistral-large-latest", "mistral-small-latest", "codestral-latest"],
  },
};

async function callAnthropic(apiKey, model, system, messages) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({ model, max_tokens: 1024, system, messages }),
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error.message);
  return data.content[0].text;
}

async function callOpenAICompat(baseURL, apiKey, model, system, messages) {
  const res = await fetch(baseURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      max_tokens: 1024,
      messages: [{ role: "system", content: system }, ...messages],
    }),
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error.message || JSON.stringify(data.error));
  return data.choices[0].message.content;
}

export const handler = async (event) => {
  // CORS headers
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json",
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }

  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Método não permitido" }) };
  }

  try {
    const { messages, system, provider = "anthropic", model } = JSON.parse(event.body);

    const cfg = PROVIDERS[provider];
    if (!cfg) return { statusCode: 400, headers, body: JSON.stringify({ error: `Provider '${provider}' inválido` }) };

    const apiKey = process.env[cfg.envKey];
    if (!apiKey) return { statusCode: 400, headers, body: JSON.stringify({ error: `${cfg.envKey} não configurada. Adiciona em Netlify → Site → Environment Variables.` }) };

    const selectedModel = model || cfg.models[0];
    const systemPrompt = system || "Você é NOVA, uma IA avançada. Responda em português do Brasil.";

    let reply;
    if (provider === "anthropic") {
      reply = await callAnthropic(apiKey, selectedModel, systemPrompt, messages);
    } else {
      reply = await callOpenAICompat(cfg.baseURL, apiKey, selectedModel, systemPrompt, messages);
    }

    return { statusCode: 200, headers, body: JSON.stringify({ reply, provider, model: selectedModel }) };
  } catch (err) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: err.message }) };
  }
};
